#!/usr/bin/env bash
# ============================================================================
#  setup-backend.sh — Compile llama.cpp (llama-server) pour votre machine
#  Requis : git, cmake, make, g++ (sudo apt install cmake make g++ git)
#  Résultat : ~/.hfllm/backend/bin/llama-server + libs
# ============================================================================
set -Eeuo pipefail

B='\033[1;34m'; G='\033[1;32m'; N='\033[0m'
say(){ printf "${B}[*]${N} %s\n" "$1"; }
ok(){  printf "${G}[OK]${N} %s\n" "$1"; }

HFLLM_HOME="${HFLLM_HOME:-$HOME/.hfllm}"
BUILD_DIR="${TMPDIR:-/tmp}/llama.cpp-build"
SRC_DIR="${TMPDIR:-/tmp}/llama.cpp-src"

for t in git cmake make g++; do
  command -v "$t" >/dev/null || { echo "outil manquant : $t (apt install $t)"; exit 1; }
done

say "Clonage de llama.cpp (superficiel)..."
git clone --depth 1 https://github.com/ggml-org/llama.cpp "$SRC_DIR" 2>/dev/null || \
  (cd "$SRC_DIR" && git pull --ff-only 2>/dev/null || true)

say "Configuration (CPU, sans BLAS/CUDA)..."
cmake -S "$SRC_DIR" -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release \
      -DGGML_CUDA=OFF -DGGML_BLAS=OFF -DGGML_VULKAN=OFF -DGGML_OPENMP=OFF -DLLAMA_CURL=OFF

say "Compilation de llama-server ($(nproc) cœurs)..."
cmake --build "$BUILD_DIR" --target llama-server -j"$(nproc)"

say "Installation dans $HFLLM_HOME/backend/bin/..."
mkdir -p "$HFLLM_HOME/backend/bin"
cp -f "$BUILD_DIR"/bin/llama-server "$HFLLM_HOME/backend/bin/"
cp -P "$BUILD_DIR"/bin/*.so* "$HFLLM_HOME/backend/bin/" 2>/dev/null || true

ok "Backend prêt : $HFLLM_HOME/backend/bin/llama-server"
"$HFLLM_HOME/backend/bin/llama-server" --version | head -1
