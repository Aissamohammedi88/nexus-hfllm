// ============================================================================
//  gguf-info.cpp — Inspecteur de fichiers GGUF (métadonnées du modèle)
//  Extrait : magic, version, nb tensors, architecture, quantisation,
//            taille de contexte, tokenizer — sans charger les tensors.
//  Usage : gguf-info modele.gguf [--json]
// ============================================================================

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>
#include <fstream>
#include <iostream>

namespace {

// Types de valeurs GGUF (spec ggml)
enum GgufType : uint32_t {
    GT_UINT8   = 0, GT_INT8    = 1, GT_UINT16 = 2, GT_INT16   = 3,
    GT_UINT32  = 4, GT_INT32   = 5, GT_FLOAT32= 6, GT_BOOL    = 7,
    GT_STRING  = 8, GT_ARRAY   = 9, GT_UINT64 = 10, GT_INT64  = 11,
    GT_FLOAT64 = 12,
};

static const char* type_name(uint32_t t) {
    switch (t) {
        case GT_UINT8: return "u8";   case GT_INT8: return "i8";
        case GT_UINT16: return "u16"; case GT_INT16: return "i16";
        case GT_UINT32: return "u32"; case GT_INT32: return "i32";
        case GT_FLOAT32: return "f32"; case GT_BOOL: return "bool";
        case GT_STRING: return "str"; case GT_ARRAY: return "arr";
        case GT_UINT64: return "u64"; case GT_INT64: return "i64";
        case GT_FLOAT64: return "f64";
    }
    return "?";
}

struct Reader {
    std::ifstream& f;
    bool ok = true;

    template <typename T>
    bool read_pod(T& out) {
        f.read(reinterpret_cast<char*>(&out), sizeof(T));
        return f.good();
    }

    bool read_str(std::string& s) {
        uint64_t len = 0;
        if (!read_pod(len)) return false;
        s.resize(len);
        if (len) f.read(s.data(), len);
        return f.good();
    }

    void skip_value(uint32_t type) {
        switch (type) {
            case GT_UINT8: case GT_INT8: case GT_BOOL: {
                uint8_t v; read_pod(v); break;
            }
            case GT_UINT16: case GT_INT16: {
                uint16_t v; read_pod(v); break;
            }
            case GT_UINT32: case GT_INT32: case GT_FLOAT32: {
                uint32_t v; read_pod(v); break;
            }
            case GT_UINT64: case GT_INT64: case GT_FLOAT64: {
                uint64_t v; read_pod(v); break;
            }
            case GT_STRING: {
                std::string s; read_str(s); break;
            }
            case GT_ARRAY: {
                uint32_t et = 0; uint64_t n = 0;
                if (!read_pod(et) || !read_pod(n)) return;
                for (uint64_t i = 0; i < n; ++i) skip_value(et);
                break;
            }
            default: ok = false; break;
        }
    }
};

std::string json_escape(const std::string& s) {
    std::string out;
    for (char c : s) {
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n";  break;
            case '\t': out += "\\t";  break;
            case '\r': out += "\\r";  break;
            default:
                if (static_cast<unsigned char>(c) < 0x20) {
                    char b[8]; snprintf(b, sizeof b, "\\u%04x", c);
                    out += b;
                } else out += c;
        }
    }
    return out;
}

struct Kv { std::string key; uint32_t type; std::string strval; std::string display; };

void read_kvs(std::ifstream& file, uint64_t count, std::vector<Kv>& out) {
    Reader r{file};
    for (uint64_t i = 0; i < count && r.ok; ++i) {
        Kv kv;
        if (!r.read_str(kv.key)) break;
        if (!r.read_pod(kv.type)) break;
        switch (kv.type) {
            case GT_UINT8: { uint8_t v; r.read_pod(v);  kv.display = std::to_string(v); break; }
            case GT_INT8:  { int8_t v;  r.read_pod(v);  kv.display = std::to_string(v); break; }
            case GT_BOOL:  { uint8_t v; r.read_pod(v);  kv.display = v ? "true" : "false"; break; }
            case GT_UINT16:{ uint16_t v;r.read_pod(v);  kv.display = std::to_string(v); break; }
            case GT_INT16: { int16_t v; r.read_pod(v);  kv.display = std::to_string(v); break; }
            case GT_UINT32:{ uint32_t v;r.read_pod(v);  kv.display = std::to_string(v); break; }
            case GT_INT32: { int32_t v; r.read_pod(v);  kv.display = std::to_string(v); break; }
            case GT_FLOAT32:{float v;   r.read_pod(v);  kv.display = std::to_string(v); break; }
            case GT_UINT64:{ uint64_t v;r.read_pod(v);  kv.display = std::to_string(v); break; }
            case GT_INT64: { int64_t v; r.read_pod(v);  kv.display = std::to_string(v); break; }
            case GT_FLOAT64:{double v;  r.read_pod(v);  kv.display = std::to_string(v); break; }
            case GT_STRING:{ std::string s; r.read_str(s); kv.strval = s; kv.display = s.size() > 200 ? s.substr(0,200)+"…" : s; break; }
            case GT_ARRAY: {
                uint32_t et = 0; uint64_t n = 0;
                if (!r.read_pod(et) || !r.read_pod(n)) { r.ok = false; break; }
                kv.display = "<" + std::string(type_name(et)) + " x " + std::to_string(n) + ">";
                // Saute les éléments (évite de lire des tableaux de 100k tokens)
                for (uint64_t i = 0; i < n && r.ok; ++i) r.skip_value(et);
                break;
            }
            default: r.ok = false; break;
        }
        if (r.ok) out.push_back(std::move(kv));
    }
}

} // namespace

int main(int argc, char** argv) {
    if (argc < 2) {
        std::fprintf(stderr, "usage : %s modele.gguf [--json]\n", argv[0]);
        return 2;
    }
    const bool as_json = argc > 2 && std::strcmp(argv[2], "--json") == 0;

    std::ifstream file(argv[1], std::ios::binary);
    if (!file) { std::fprintf(stderr, "impossible d'ouvrir %s\n", argv[1]); return 1; }

    char magic[4] = {0};
    file.read(magic, 4);
    if (std::memcmp(magic, "GGUF", 4) != 0) {
        std::fprintf(stderr, "magic invalide : pas un fichier GGUF\n");
        return 1;
    }
    uint32_t version = 0; uint64_t tensors = 0, kvs = 0;
    file.read(reinterpret_cast<char*>(&version), 4);
    file.read(reinterpret_cast<char*>(&tensors), 8);
    file.read(reinterpret_cast<char*>(&kvs), 8);

    std::vector<Kv> kvs_list;
    read_kvs(file, kvs, kvs_list);

    // Index utile
    std::unordered_map<std::string, const Kv*> idx;
    for (const auto& kv : kvs_list) idx[kv.key] = &kv;

    auto get = [&](const std::string& k) -> std::string {
        auto it = idx.find(k);
        return it == idx.end() ? "" : (it->second->type == GT_STRING ? it->second->strval : it->second->display);
    };

    std::string arch = get("general.architecture");
    if (arch.empty()) arch = "?";
    std::string name = get("general.name");
    std::string ft   = get("general.file_type");
    std::string ctx  = get(arch + ".context_length");
    std::string emb  = get(arch + ".embedding_length");
    std::string blk  = get(arch + ".block_count");
    std::string head = get(arch + ".attention.head_count");
    std::string kvh  = get(arch + ".attention.key_length");
    if (kvh.empty()) kvh = get(arch + ".attention.head_count_kv");
    std::string vocab= get("tokenizer.ggml.model");

    if (as_json) {
        std::printf("{\"file\":\"%s\",\"version\":%u,\"tensors\":%llu,\"kv_count\":%llu,",
                    json_escape(argv[1]).c_str(), version,
                    (unsigned long long)tensors, (unsigned long long)kvs);
        std::printf("\"name\":\"%s\",\"architecture\":\"%s\",\"quant\":\"%s\",\"ctx\":\"%s\",\"embed\":\"%s\",\"blocks\":\"%s\",\"heads\":\"%s\",\"vocab_type\":\"%s\",\"bytes\":%llu,",
                    json_escape(name).c_str(), json_escape(arch).c_str(),
                    json_escape(ft).c_str(), json_escape(ctx).c_str(),
                    json_escape(emb).c_str(), json_escape(blk).c_str(),
                    json_escape(head).c_str(), json_escape(vocab).c_str(),
                    (unsigned long long)std::ifstream(argv[1], std::ios::binary | std::ios::ate).tellg());
        std::printf("\"metadata\":[");
        bool first = true;
        for (const auto& kv : kvs_list) {
            if (!first) std::printf(",");
            first = false;
            std::printf("{\"key\":\"%s\",\"type\":\"%s\",\"value\":\"%s\"}",
                        json_escape(kv.key).c_str(), type_name(kv.type), json_escape(kv.display).c_str());
        }
        std::printf("]}\n");
    } else {
        std::printf("fichier       : %s\n", argv[1]);
        std::printf("gguf version  : %u\n", version);
        std::printf("tensors       : %llu\n", (unsigned long long)tensors);
        std::printf("metadonnées   : %llu\n", (unsigned long long)kvs_list.size());
        std::printf("nom           : %s\n", name.c_str());
        std::printf("architecture  : %s\n", arch.c_str());
        std::printf("quantisation  : %s\n", ft.c_str());
        std::printf("contexte      : %s\n", ctx.c_str());
        std::printf("embedding     : %s\n", emb.c_str());
        std::printf("blocs         : %s\n", blk.c_str());
        std::printf("têtes         : %s\n", head.c_str());
        std::printf("tokenizer     : %s\n", vocab.c_str());
        std::printf("--- toutes les métadonnées ---\n");
        for (const auto& kv : kvs_list) {
            std::printf("  %-48s [%-4s] %s\n", kv.key.c_str(), type_name(kv.type), kv.display.c_str());
        }
    }
    return 0;
}
