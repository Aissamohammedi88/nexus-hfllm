// ============================================================================
//  hfllm — Cousin LLM Launcher (remplace Ollama)
//  * n'importe quel modèle GGUF depuis Hugging Face   → `hfllm pull owner/repo`
//  * serveur OpenAI-compatible (llama.cpp llama-server) → `hfllm serve MODELE`
//  * chat + mémoire persistante SQLite                  → `hfllm chat MODELE`
//  En hommage au créateur originel — Repose en paix.
// ============================================================================

use std::io::{self, Read, IsTerminal, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

use anyhow::{anyhow, bail, Context, Result};
use clap::{Parser, Subcommand};
use rusqlite::{params, Connection};
use serde_json::{json, Value};

const HF_API: &str = "https://huggingface.co/api/models";
const HF_RESOLVE: &str = "https://huggingface.co";
const QUANT_PREFERENCE: &[&str] = &[
    "Q4_K_M", "Q4_K_S", "Q5_K_M", "Q5_K_S", "Q3_K_M", "Q3_K_L", "Q8_0", "Q6_K", "Q4_0", "IQ4_XS",
];

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------

#[derive(Parser)]
#[command(
    name = "hfllm",
    version,
    about = "Cousin LLM Launcher — lance n'importe quel modèle HF, mémoire persistante",
    after_help = "En hommage au créateur originel — Repose en paix."
)]
struct Cli {
    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(Subcommand)]
enum Cmd {
    /// Télécharge un modèle GGUF : owner/repo | owner/repo:fichier.gguf | URL
    Pull { source: String },
    /// Liste les modèles téléchargés (--json pour le dashboard)
    List {
        #[arg(long)]
        json: bool,
    },
    /// Démarre le serveur d'inférence OpenAI-compatible pour un modèle
    Serve {
        model: String,
        #[arg(long, default_value_t = 11434)]
        port: u16,
        /// Taille du contexte (-c de llama-server)
        #[arg(long, default_value_t = 4096)]
        ctx: u32,
        /// Couches GPU (-ngl, 0 = CPU pur)
        #[arg(long, default_value_t = 0)]
        ngl: u32,
        /// Arrête tous les serveurs hfllm
        #[arg(long)]
        stop: bool,
    },
    /// Chat interactif avec mémoire persistante (--session pour plusieurs fils)
    Chat {
        model: String,
        #[arg(long, default_value = "default")]
        session: String,
        #[arg(long, default_value_t = 11434)]
        port: u16,
    },
    /// Prompt unique (persiste aussi en mémoire) ; --json pour le dashboard
    Run {
        model: String,
        prompt: Option<String>,
        #[arg(long, default_value = "default")]
        session: String,
        #[arg(long, default_value_t = 11434)]
        port: u16,
        #[arg(long)]
        json: bool,
    },
    /// Mémoire persistante : list | show | clear | stats
    Mem {
        #[command(subcommand)]
        cmd: MemCmd,
    },
    /// Métadonnées GGUF (appelle l'outil C++ gguf-info si présent)
    Info { model: String },
    /// Supprime un modèle
    Rm { model: String },
}

#[derive(Subcommand)]
enum MemCmd {
    /// Liste les sessions et leur nombre de messages
    List {
        #[arg(long)]
        json: bool,
    },
    /// Affiche tout le fil d'une session
    Show {
        #[arg(long, default_value = "default")]
        session: String,
    },
    /// Efface une session
    Clear {
        #[arg(long, default_value = "default")]
        session: String,
    },
    /// Statistiques globales de la mémoire
    Stats {
        #[arg(long)]
        json: bool,
    },
}

// ---------------------------------------------------------------------------
// Chemins / environnement
// ---------------------------------------------------------------------------

fn hfllm_home() -> PathBuf {
    if let Ok(p) = std::env::var("HFLLM_HOME") {
        PathBuf::from(p)
    } else if let Ok(h) = std::env::var("HOME") {
        Path::new(&h).join(".hfllm")
    } else {
        PathBuf::from(".hfllm")
    }
}

fn models_dir() -> PathBuf {
    hfllm_home().join("models")
}

fn db_path() -> PathBuf {
    hfllm_home().join("memory.db")
}

fn logs_dir() -> PathBuf {
    hfllm_home().join("logs")
}

/// Résout le binaire llama-server : env → ~/.hfllm/backend → ./bin/backend → PATH
fn find_backend() -> PathBuf {
    if let Ok(p) = std::env::var("HFLLM_BACKEND") {
        let pb = PathBuf::from(p);
        if pb.exists() {
            return pb;
        }
    }
    let candidates = [
        hfllm_home().join("backend/bin/llama-server"),
        exe_dir().join("bin/backend/llama-server"),
        exe_dir().join("backend/llama-server"),
    ];
    for c in &candidates {
        if c.exists() {
            return c.clone();
        }
    }
    PathBuf::from("llama-server")
}

fn exe_dir() -> PathBuf {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|p| p.to_path_buf()))
        .unwrap_or_else(|| PathBuf::from("."))
}

/// Résout l'outil C++ gguf-info (même logique que le backend)
fn find_gguf_info() -> Option<PathBuf> {
    let candidates = [
        hfllm_home().join("tools/gguf-info"),
        exe_dir().join("gguf-info"),
        exe_dir().join("bin/gguf-info"),
    ];
    for c in &candidates {
        if c.exists() {
            return Some(c.clone());
        }
    }
    None
}

// ---------------------------------------------------------------------------
// Base de données (mémoire persistante)
// ---------------------------------------------------------------------------

fn open_db() -> Result<Connection> {
    std::fs::create_dir_all(hfllm_home())?;
    let conn = Connection::open(db_path())?;
    conn.execute_batch(
        "PRAGMA journal_mode = WAL;
         CREATE TABLE IF NOT EXISTS models (
             name    TEXT PRIMARY KEY,
             file    TEXT NOT NULL,
             repo    TEXT NOT NULL DEFAULT '',
             size    INTEGER NOT NULL DEFAULT 0,
             added   TEXT NOT NULL DEFAULT (datetime('now'))
         );
         CREATE TABLE IF NOT EXISTS sessions (
             name    TEXT PRIMARY KEY,
             created TEXT NOT NULL DEFAULT (datetime('now'))
         );
         CREATE TABLE IF NOT EXISTS messages (
             id         INTEGER PRIMARY KEY AUTOINCREMENT,
             session    TEXT NOT NULL,
             role       TEXT NOT NULL,
             content    TEXT NOT NULL,
             created    TEXT NOT NULL DEFAULT (datetime('now'))
         );
         CREATE INDEX IF NOT EXISTS idx_msg_session ON messages(session, id);
         CREATE TABLE IF NOT EXISTS servers (
             model     TEXT PRIMARY KEY,
             port      INTEGER NOT NULL,
             pid       INTEGER NOT NULL,
             started   TEXT NOT NULL DEFAULT (datetime('now'))
         );",
    )?;
    Ok(conn)
}

fn save_message(conn: &Connection, session: &str, role: &str, content: &str) -> Result<()> {
    conn.execute(
        "INSERT INTO sessions(name) VALUES(?1) ON CONFLICT(name) DO NOTHING",
        params![session],
    )?;
    conn.execute(
        "INSERT INTO messages(session, role, content) VALUES(?1, ?2, ?3)",
        params![session, role, content],
    )?;
    Ok(())
}

fn load_history(conn: &Connection, session: &str, limit: i64) -> Result<Vec<Value>> {
    let mut stmt = conn.prepare(
        "SELECT role, content FROM (
             SELECT id, role, content FROM messages
             WHERE session = ?1 ORDER BY id DESC LIMIT ?2
         ) ORDER BY id ASC",
    )?;
    let rows = stmt.query_map(params![session, limit], |r| {
        Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?))
    })?;
    let mut v = Vec::new();
    for row in rows {
        let (role, content) = row?;
        v.push(json!({"role": role, "content": content}));
    }
    Ok(v)
}

// ---------------------------------------------------------------------------
// Hugging Face : résolution + téléchargement
// ---------------------------------------------------------------------------

/// Entrées possibles : URL directe .gguf, `owner/repo`, `owner/repo:fichier.gguf`
fn resolve_model(source: &str) -> Result<(String /*url*/, String /*name*/, String /*repo*/)> {
    if source.contains("://") {
        let url = source.to_string();
        let name = url
            .rsplit('/')
            .next()
            .unwrap_or("model.gguf")
            .trim_end_matches(".gguf")
            .to_string();
        return Ok((url, name, "url".to_string()));
    }

    let (repo, wanted) = match source.split_once(':') {
        Some((r, f)) if !f.is_empty() => (r.to_string(), Some(f.to_string())),
        _ => (source.to_string(), None),
    };

    println!("[*] Interrogation de Hugging Face : {}", repo);
    let api = format!("{}/{}/tree/main", HF_API, repo);
    let resp = ureq::get(&api)
        .timeout(Duration::from_secs(60))
        .call()
        .with_context(|| format!("API HF injoignable pour « {} »", repo))?;
    let tree: Vec<Value> = resp.into_json().context("Réponse HF illisible")?;

    let files: Vec<(String, f64)> = tree
        .iter()
        .filter_map(|e| {
            let path = e.get("path")?.as_str()?;
            let size = e.get("size").and_then(|s| s.as_f64()).unwrap_or(0.0);
            if path.ends_with(".gguf") && !path.contains('/') {
                Some((path.to_string(), size))
            } else {
                None
            }
        })
        .collect();

    if files.is_empty() {
        bail!("Aucun fichier .gguf trouvé dans le dépôt « {} »", repo);
    }

    // Fichier demandé explicitement ?
    if let Some(w) = &wanted {
        let hit = files.iter().find(|(p, _)| p == w).ok_or_else(|| {
            anyhow!(
                "« {} » absent du dépôt. Fichiers : {}",
                w,
                files.iter().map(|f| f.0.as_str()).collect::<Vec<_>>().join(", ")
            )
        })?;
        return Ok((
            format!("{}/{}/resolve/main/{}", HF_RESOLVE, repo, hit.0),
            hit.0.trim_end_matches(".gguf").to_string(),
            repo,
        ));
    }

    // Évite les fichiers découpés (…-00001-of-00003.gguf) si un fichier unique existe
    let single: Vec<_> = files.iter().filter(|(p, _)| !p.contains("-of-")).collect();
    let pool: Vec<(String, f64)> = if single.is_empty() {
        files.clone()
    } else {
        single.into_iter().cloned().collect()
    };

    // Quantisation préférée, sinon le plus gros fichier (souvent le meilleur)
    let chosen = QUANT_PREFERENCE
        .iter()
        .find_map(|q| pool.iter().find(|(p, _)| p.contains(q)))
        .or_else(|| pool.iter().max_by(|a, b| a.1.total_cmp(&b.1)))
        .cloned()
        .ok_or_else(|| anyhow!("sélection impossible"))?;

    println!("[OK] Choix : {} ({:.1} Mo)", chosen.0, chosen.1 / 1e6);
    Ok((
        format!("{}/{}/resolve/main/{}", HF_RESOLVE, repo, chosen.0),
        chosen.0.trim_end_matches(".gguf").to_string(),
        repo,
    ))
}

fn http_size(url: &str) -> Result<Option<u64>> {
    let resp = ureq::head(url).timeout(Duration::from_secs(60)).call();
    match resp {
        Ok(r) => Ok(r.header("content-length").and_then(|h| h.parse().ok())),
        Err(_) => Ok(None),
    }
}

fn download(url: &str, dest: &Path) -> Result<()> {
    std::fs::create_dir_all(dest.parent().unwrap())?;
    let existing = dest.metadata().map(|m| m.len()).unwrap_or(0);
    if let Some(total) = http_size(url)? {
        if total > 0 && existing == total {
            println!("[OK] Déjà téléchargé : {}", dest.display());
            return Ok(());
        }
    }

    let mut file = if existing > 0 {
        println!("[*] Reprise du téléchargement à {} Mo", existing / 1_000_000);
        std::fs::OpenOptions::new().append(true).open(dest)?
    } else {
        std::fs::File::create(dest)?
    };

    let url_owned = url.to_string();
    let resp = if existing > 0 {
        ureq::get(&url_owned)
            .set("Range", &format!("bytes={}-", existing))
            .call()
    } else {
        ureq::get(&url_owned).call()
    }
    .map_err(|e| anyhow!("téléchargement échoué : {}", e))?;

    let total: Option<u64> = resp
        .header("content-length")
        .and_then(|h| h.parse().ok())
        .map(|l: u64| l + existing);
    let mut reader = resp.into_reader();
    let mut buf = [0u8; 65536];
    let mut done = existing;
    let start = Instant::now();
    let mut last_print = Instant::now();

    loop {
        let n = reader.read(&mut buf)?;
        if n == 0 {
            break;
        }
        file.write_all(&buf[..n])?;
        done += n as u64;
        if last_print.elapsed() >= Duration::from_millis(700) {
            last_print = Instant::now();
            let secs = start.elapsed().as_secs_f64().max(0.1);
            let speed = (done - existing) as f64 / 1e6 / secs;
            match total {
                Some(t) => print!(
                    "\r[*] {:>7.1} / {:.1} Mo   {:>5.1} %   {:.1} Mo/s ",
                    done as f64 / 1e6,
                    t as f64 / 1e6,
                    done as f64 / t as f64 * 100.0,
                    speed
                ),
                None => print!("\r[*] {:.1} Mo téléchargés  {:.1} Mo/s ", done as f64 / 1e6, speed),
            }
            io::stdout().flush()?;
        }
    }
    println!("\r[OK] {}  ({:.1} Mo)                    ", dest.display(), done as f64 / 1e6);
    Ok(())
}

// ---------------------------------------------------------------------------
// Serveur llama.cpp
// ---------------------------------------------------------------------------

fn pid_alive(pid: i64) -> bool {
    unsafe { libc::kill(pid as libc::pid_t, 0) == 0 }
}

fn spawn_server(model_file: &Path, port: u16, ctx: u32, ngl: u32) -> Result<i64> {
    let backend = find_backend();
    if !backend.exists() && backend.as_os_str() != "llama-server" {
        bail!(
            "Backend llama-server introuvable ({}).\n→ Lancez scripts/setup-backend.sh ou placez-le dans ~/.hfllm/backend/bin/",
            backend.display()
        );
    }
    std::fs::create_dir_all(logs_dir())?;
    let log = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(logs_dir().join(format!("llama-server-{}.log", port)))?;

    let mut cmd = Command::new(&backend);
    cmd.arg("-m").arg(model_file)
        .arg("--host").arg("127.0.0.1")
        .arg("--port").arg(port.to_string())
        .arg("-c").arg(ctx.to_string())
        .arg("-ngl").arg(ngl.to_string())
        .stdout(Stdio::from(log.try_clone()?))
        .stderr(Stdio::from(log));
    // Le llama-server livré embarque ses .so à côté de lui : runpath $ORIGIN portable
    if let Some(dir) = backend.parent() {
        let libdir = dir.to_string_lossy().to_string();
        let existing = std::env::var("LD_LIBRARY_PATH").unwrap_or_default();
        let combined = if existing.is_empty() { libdir } else { format!("{}:{}", libdir, existing) };
        cmd.env("LD_LIBRARY_PATH", combined);
    }
    // Détache : le serveur survit à la fin du launcher (comme ollama serve)
    unsafe {
        use std::os::unix::process::CommandExt;
        cmd.pre_exec(|| {
            libc::setsid();
            Ok(())
        });
    }
    let child = cmd
        .spawn()
        .with_context(|| format!("échec du lancement de {}", backend.display()))?;
    let pid = child.id() as i64;
    Ok(pid)
}

fn wait_health(port: u16, secs: u64) -> bool {
    let url = format!("http://127.0.0.1:{}/health", port);
    let deadline = Instant::now() + Duration::from_secs(secs);
    while Instant::now() < deadline {
        if let Ok(r) = ureq::get(&url).timeout(Duration::from_secs(2)).call() {
            if r.status() == 200 {
                return true;
            }
        }
        std::thread::sleep(Duration::from_millis(500));
    }
    false
}

/// S'assure qu'un serveur tourne pour `model` sur `port` ; le démarre sinon.
fn ensure_server(conn: &Connection, model_name: &str, model_file: &Path, port: u16, ctx: u32, ngl: u32) -> Result<()> {
    // Serveur déjà connu pour ce modèle ?
    if let Ok((pid, p)) = conn.query_row(
        "SELECT pid, port FROM servers WHERE model = ?1",
        params![model_name],
        |r| Ok((r.get::<_, i64>(0)?, r.get::<_, u16>(1)?)),
    ) {
        if pid_alive(pid) {
            if p != port {
                // Port différent demandé : le redémarrer sur le bon port
                unsafe { libc::kill(pid as libc::pid_t, libc::SIGTERM) };
            } else if wait_health(port, 5) {
                return Ok(());
            }
        }
        conn.execute("DELETE FROM servers WHERE model = ?1", params![model_name])?;
    }

    // Port déjà occupé par un autre serveur hfllm ? (modèle différent)
    if wait_health(port, 1) {
        if let Ok((other, pid)) = conn.query_row(
            "SELECT model, pid FROM servers WHERE port = ?1",
            params![port],
            |r| Ok((r.get::<_, String>(0)?, r.get::<_, i64>(1)?)),
        ) {
            if other != model_name {
                bail!(
                    "Le port {} est déjà utilisé par « {} » (pid {}). → hfllm serve {} --stop puis re-servez, ou choisissez --port autre.",
                    port, other, pid, other
                );
            }
        } else {
            bail!("Le port {} est occupé par un autre service.", port);
        }
    }

    println!("[*] Démarrage du serveur pour « {} » (port {})...", model_name, port);
    let pid = spawn_server(model_file, port, ctx, ngl)?;
    if !wait_health(port, 120) {
        let _ = unsafe { libc::kill(pid as libc::pid_t, libc::SIGTERM) };
        bail!(
            "Le serveur n'est pas devenu prêt (120 s). Log : {}",
            logs_dir().join(format!("llama-server-{}.log", port)).display()
        );
    }
    conn.execute(
        "INSERT INTO servers(model, port, pid) VALUES(?1, ?2, ?3)
         ON CONFLICT(model) DO UPDATE SET port=?2, pid=?3, started=datetime('now')",
        params![model_name, port, pid],
    )?;
    println!("[OK] Serveur prêt : http://127.0.0.1:{} (pid {})", port, pid);
    Ok(())
}

// ---------------------------------------------------------------------------
// Inférence (API OpenAI-compatible de llama-server)
// ---------------------------------------------------------------------------

fn chat_completion(port: u16, messages: &[Value]) -> Result<(String, Value)> {
    let url = format!("http://127.0.0.1:{}/v1/chat/completions", port);
    let body = json!({
        "messages": messages,
        "temperature": 0.7,
        "stream": false
    });
    let resp = ureq::post(&url)
        .timeout(Duration::from_secs(600))
        .send_json(body)
        .map_err(|e| anyhow!("appel au serveur échoué : {}", e))?;
    let v: Value = resp.into_json()?;
    let content = v["choices"][0]["message"]["content"]
        .as_str()
        .unwrap_or("")
        .to_string();
    Ok((content, v))
}

fn resolve_model_file(conn: &Connection, name: &str) -> Result<(PathBuf, String)> {
    let file: String = conn
        .query_row("SELECT file FROM models WHERE name = ?1", params![name], |r| r.get(0))
        .with_context(|| format!("modèle « {} » inconnu → hfllm pull d'abord", name))?;
    let p = PathBuf::from(&file);
    if !p.exists() {
        bail!("fichier absent : {}", p.display());
    }
    Ok((p, file))
}

// ---------------------------------------------------------------------------
// Commandes
// ---------------------------------------------------------------------------

fn cmd_run_from_input(model: String, prompt: Option<String>, session: String, port: u16, json_out: bool) -> Result<()> {
    let prompt = match prompt {
        Some(p) => p,
        None => {
            let mut s = String::new();
            io::stdin()
                .read_to_string(&mut s)
                .context("lecture de stdin")?;
            s.trim().to_string()
        }
    };
    if prompt.is_empty() {
        bail!("prompt vide");
    }
    do_run(&model, &prompt, &session, port, json_out)
}

fn cmd_pull(source: &str) -> Result<()> {
    let (url, name, repo) = resolve_model(source)?;
    let dest = models_dir().join(format!("{}.gguf", name));
    download(&url, &dest)?;
    let size = std::fs::metadata(&dest)?.len();
    let conn = open_db()?;
    conn.execute(
        "INSERT INTO models(name, file, repo, size) VALUES(?1, ?2, ?3, ?4)
         ON CONFLICT(name) DO UPDATE SET file=?2, repo=?3, size=?4",
        params![name, dest.display().to_string(), repo, size],
    )?;
    println!("[OK] Modèle « {} » enregistré ({} Mo)", name, size / 1_000_000);
    println!("     → hfllm chat {}   |   hfllm serve {}   |   hfllm info {}", name, name, name);
    Ok(())
}

fn cmd_list(json_out: bool) -> Result<()> {
    let conn = open_db()?;
    let mut stmt = conn.prepare("SELECT name, file, repo, size, added FROM models ORDER BY name")?;
    let rows: Vec<(String, String, String, i64, String)> = stmt
        .query_map([], |r| {
            Ok((
                r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?, r.get(4)?,
            ))
        })?
        .collect::<std::result::Result<_, _>>()?;

    if json_out {
        let arr: Vec<Value> = rows
            .iter()
            .map(|(n, f, repo, s, a)| json!({"name": n, "file": f, "repo": repo, "size": s, "added": a}))
            .collect();
        println!("{}", serde_json::to_string_pretty(&arr)?);
        return Ok(());
    }
    if rows.is_empty() {
        println!("Aucun modèle. → hfllm pull owner/repo  (ex : hfllm pull bartowski/SmolLM2-135M-Instruct-GGUF)");
        return Ok(());
    }
    println!("{:<38} {:>10}  {:<28} {}", "MODÈLE", "TAILLE", "DÉPÔT HF", "AJOUTÉ");
    for (n, _, repo, s, a) in &rows {
        println!("{:<38} {:>8} Mo  {:<28} {}", n, s / 1_000_000, repo, a);
    }
    Ok(())
}

fn cmd_serve(model: &str, port: u16, ctx: u32, ngl: u32, stop: bool) -> Result<()> {
    let conn = open_db()?;
    if stop {
        let mut stmt = conn.prepare("SELECT model, pid FROM servers")?;
        let rows: Vec<(String, i64)> = stmt
            .query_map([], |r| Ok((r.get(0)?, r.get(1)?)))?
            .collect::<std::result::Result<_, _>>()?;
        for (m, pid) in rows {
            if pid_alive(pid) {
                unsafe { libc::kill(pid as libc::pid_t, libc::SIGTERM) };
                println!("[OK] serveur « {} » (pid {}) arrêté", m, pid);
            }
        }
        conn.execute("DELETE FROM servers", [])?;
        return Ok(());
    }
    let (file, _) = resolve_model_file(&conn, model)?;
    ensure_server(&conn, model, &file, port, ctx, ngl)?;
    println!("API : {}/v1/chat/completions  (compatible OpenAI)", format!("http://127.0.0.1:{}", port));
    Ok(())
}

fn do_run(model: &str, prompt: &str, session: &str, port: u16, json_out: bool) -> Result<()> {
    let conn = open_db()?;
    let (file, _) = resolve_model_file(&conn, model)?;
    ensure_server(&conn, model, &file, port, 4096, 0)?;

    let history = load_history(&conn, session, 50)?;
    let mut messages = history;
    messages.push(json!({"role": "user", "content": prompt}));

    let started = Instant::now();
    let (reply, usage) = chat_completion(port, &messages)?;
    save_message(&conn, session, "user", prompt)?;
    save_message(&conn, session, "assistant", &reply)?;

    if json_out {
        println!("{}", json!({
            "reply": reply,
            "session": session,
            "model": model,
            "ms": started.elapsed().as_millis(),
            "usage": usage.get("usage").cloned().unwrap_or(Value::Null),
        }));
    } else {
        println!("{}", reply);
    }
    Ok(())
}

fn cmd_chat(model: &str, session: &str, port: u16) -> Result<()> {
    let conn = open_db()?;
    let (file, _) = resolve_model_file(&conn, model)?;
    ensure_server(&conn, model, &file, port, 4096, 0)?;

    let count: i64 = conn.query_row(
        "SELECT COUNT(*) FROM messages WHERE session = ?1",
        params![session],
        |r| r.get::<_, i64>(0),
    )?;
    println!("──────────────────────────────────────────────────────");
    println!(" hfllm chat · modèle « {} » · session « {} »", model, session);
    if count > 0 {
        println!(" mémoire chargée : {} message(s) déjà enregistrés", count);
    }
    println!(" commandes : /mem  /reset  /exit   (Ctrl+D pour sortir)");
    println!("──────────────────────────────────────────────────────");

    if !io::stdin().is_terminal() {
        bail!("chat interactif nécessite un TTY ; pour un prompt unique : hfllm run {} \"…\"", model);
    }

    // stdin est déjà bufferisé
    let mut line = String::new();
    loop {
        print!("\nvous › ");
        io::stdout().flush()?;
        line.clear();
        let n = io::stdin().read_line(&mut line)?;
        if n == 0 {
            println!("\n[fin] — mémoire conservée en {}", db_path().display());
            break;
        }
        let msg = line.trim();
        match msg {
            "" => continue,
            "/exit" | "/quit" => {
                println!("[fin] — mémoire conservée en {}", db_path().display());
                break;
            }
            "/reset" => {
                conn.execute("DELETE FROM messages WHERE session = ?1", params![session])?;
                println!("[OK] session « {} » effacée", session);
                continue;
            }
            "/mem" => {
                let c: i64 = conn.query_row(
                    "SELECT COUNT(*) FROM messages WHERE session = ?1",
                    params![session],
                    |r| r.get::<_, i64>(0),
                )?;
                println!("[mem] {} message(s) dans « {} »", c, session);
                continue;
            }
            "/help" => {
                println!("commandes : /mem /reset /exit");
                continue;
            }
            _ => {}
        }

        let history = load_history(&conn, session, 50)?;
        let mut messages = history;
        messages.push(json!({"role": "user", "content": msg}));
        print!("hfllm › ");
        io::stdout().flush()?;
        match chat_completion(port, &messages) {
            Ok((reply, _)) => {
                save_message(&conn, session, "user", msg)?;
                save_message(&conn, session, "assistant", &reply)?;
                println!("{}", reply);
            }
            Err(e) => println!("[erreur] {}", e),
        }
    }
    Ok(())
}

fn cmd_mem_list(json_out: bool) -> Result<()> {
    let conn = open_db()?;
    let mut stmt = conn.prepare(
        "SELECT s.name, COUNT(m.id), COALESCE(MAX(m.created), s.created)
         FROM sessions s LEFT JOIN messages m ON m.session = s.name
         GROUP BY s.name ORDER BY s.name",
    )?;
    let rows: Vec<(String, i64, String)> = stmt
        .query_map([], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)))?
        .collect::<std::result::Result<_, _>>()?;
    if json_out {
        let arr: Vec<Value> = rows
            .iter()
            .map(|(n, c, last)| json!({"session": n, "messages": c, "last": last}))
            .collect();
        println!("{}", serde_json::to_string_pretty(&arr)?);
        return Ok(());
    }
    if rows.is_empty() {
        println!("Mémoire vide.");
        return Ok(());
    }
    println!("{:<24} {:>9}  {}", "SESSION", "MESSAGES", "DERNIÈRE ACTIVITÉ");
    for (n, c, last) in &rows {
        println!("{:<24} {:>9}  {}", n, c, last);
    }
    Ok(())
}

fn cmd_mem_show(session: &str) -> Result<()> {
    let conn = open_db()?;
    let mut stmt = conn.prepare(
        "SELECT role, content, created FROM messages WHERE session = ?1 ORDER BY id",
    )?;
    let rows: Vec<(String, String, String)> = stmt
        .query_map(params![session], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)))?
        .collect::<std::result::Result<_, _>>()?;
    if rows.is_empty() {
        println!("Session « {} » vide.", session);
        return Ok(());
    }
    for (role, content, at) in rows {
        println!("[{}] {}  {}", at, role, content);
    }
    Ok(())
}

fn cmd_mem_clear(session: &str) -> Result<()> {
    let conn = open_db()?;
    let n = conn.execute("DELETE FROM messages WHERE session = ?1", params![session])?;
    conn.execute("DELETE FROM sessions WHERE name = ?1", params![session])?;
    println!("[OK] {} message(s) effacés de « {} »", n, session);
    Ok(())
}

fn cmd_mem_stats(json_out: bool) -> Result<()> {
    let conn = open_db()?;
    let msgs: i64 = conn.query_row("SELECT COUNT(*) FROM messages", [], |r| r.get::<_, i64>(0))?;
    let sess: i64 = conn.query_row("SELECT COUNT(*) FROM sessions", [], |r| r.get::<_, i64>(0))?;
    let models: i64 = conn.query_row("SELECT COUNT(*) FROM models", [], |r| r.get::<_, i64>(0))?;
    let bytes: i64 = conn.query_row("SELECT COALESCE(SUM(size),0) FROM models", [], |r| r.get::<_, i64>(0))?;
    if json_out {
        println!("{}", json!({"messages": msgs, "sessions": sess, "models": models, "bytes": bytes}));
        return Ok(());
    }
    println!("messages={} sessions={} modèles={} octets GGUF={}", msgs, sess, models, bytes);
    Ok(())
}

fn cmd_info(model: &str) -> Result<()> {
    let conn = open_db()?;
    let (file, _) = resolve_model_file(&conn, model)?;
    match find_gguf_info() {
        Some(tool) => {
            let st = Command::new(tool).arg(&file).status()
                .with_context(|| "exécution de gguf-info")?;
            if !st.success() {
                bail!("gguf-info a échoué (code {:?})", st.code());
            }
        }
        None => {
            // secours minimal : taille + magic
            let meta = std::fs::metadata(&file)?;
            println!("fichier : {}", file.display());
            println!("taille  : {:.1} Mo", meta.len() as f64 / 1e6);
            println!("(outil gguf-info absent → scripts/setup-backend.sh l'installe)");
        }
    }
    Ok(())
}

fn cmd_rm(model: &str) -> Result<()> {
    let conn = open_db()?;
    let file: String = conn
        .query_row("SELECT file FROM models WHERE name = ?1", params![model], |r| r.get::<_, String>(0))
        .with_context(|| format!("modèle « {} » inconnu", model))?;
    std::fs::remove_file(&file).with_context(|| format!("suppression de {}", file))?;
    conn.execute("DELETE FROM models WHERE name = ?1", params![model])?;
    println!("[OK] « {} » supprimé ({})", model, file);
    Ok(())
}

// ---------------------------------------------------------------------------

fn main() {
    let cli = Cli::parse();
    let res = match cli.cmd {
        Cmd::Pull { source } => cmd_pull(&source),
        Cmd::List { json } => cmd_list(json),
        Cmd::Serve { model, port, ctx, ngl, stop } => cmd_serve(&model, port, ctx, ngl, stop),
        Cmd::Chat { model, session, port } => cmd_chat(&model, &session, port),
        Cmd::Run { model, prompt, session, port, json } => {
            cmd_run_from_input(model, prompt, session, port, json)
        }
        Cmd::Mem { cmd } => match cmd {
            MemCmd::List { json } => cmd_mem_list(json),
            MemCmd::Show { session } => cmd_mem_show(&session),
            MemCmd::Clear { session } => cmd_mem_clear(&session),
            MemCmd::Stats { json } => cmd_mem_stats(json),
        },
        Cmd::Info { model } => cmd_info(&model),
        Cmd::Rm { model } => cmd_rm(&model),
    };
    if let Err(e) = res {
        eprintln!("[X] {}", e);
        let mut src = e.source();
        while let Some(s) = src {
            eprintln!("     ↳ {}", s);
            src = s.source();
        }
        std::process::exit(1);
    }
}
