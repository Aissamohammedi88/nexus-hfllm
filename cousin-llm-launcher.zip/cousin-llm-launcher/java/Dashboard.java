// ============================================================================
//  Dashboard.java — Tableau de bord web du Cousin LLM Launcher
//  * Serveur HTTP natif JDK (com.sun.net.httpserver) — zéro dépendance
//  * Orchestre hfllm (Rust) via ProcessBuilder : un seul store mémoire SQLite
//  * Chat web → hfllm run --json  → llama-server (OpenAI-compatible)
//  Lancement : java Dashboard.java  (port 8686)
//  En hommage au créateur originel — Repose en paix.
// ============================================================================

import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.Executors;

public class Dashboard {

    // ------------------------------------------------------------------
    // Mini-parser JSON (récursif, zéro dépendance) — pour les sorties hfllm
    // ------------------------------------------------------------------
    static final class Json {
        private final String s; private int i = 0;
        private Json(String s) { this.s = s; }
        static Object parse(String text) {
            Json p = new Json(text);
            p.ws();
            Object v = p.value();
            return v;
        }
        private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        private Object value() {
            ws();
            if (i >= s.length()) return null;
            char c = s.charAt(i);
            switch (c) {
                case '{': return obj();
                case '[': return arr();
                case '"': return str();
                case 't': i += 4; return Boolean.TRUE;
                case 'f': i += 5; return Boolean.FALSE;
                case 'n': i += 4; return null;
                default: return num();
            }
        }
        @SuppressWarnings("unchecked")
        private Map<String, Object> obj() {
            Map<String, Object> m = new LinkedHashMap<>();
            i++; ws();
            if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
            while (true) {
                ws();
                String k = str();
                ws(); i++; // ':'
                Object v = value();
                m.put(k, v);
                ws();
                char c = s.charAt(i++);
                if (c == '}') break;
            }
            return m;
        }
        @SuppressWarnings("unchecked")
        private List<Object> arr() {
            List<Object> l = new ArrayList<>();
            i++; ws();
            if (i < s.length() && s.charAt(i) == ']') { i++; return l; }
            while (true) {
                l.add(value());
                ws();
                char c = s.charAt(i++);
                if (c == ']') break;
            }
            return l;
        }
        private String str() {
            StringBuilder b = new StringBuilder();
            i++; // opening quote
            while (i < s.length()) {
                char c = s.charAt(i++);
                if (c == '"') break;
                if (c == '\\') {
                    char e = s.charAt(i++);
                    switch (e) {
                        case 'n': b.append('\n'); break;
                        case 't': b.append('\t'); break;
                        case 'r': b.append('\r'); break;
                        case 'b': b.append('\b'); break;
                        case 'f': b.append('\f'); break;
                        case 'u':
                            b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; break;
                        default: b.append(e);
                    }
                } else b.append(c);
            }
            return b.toString();
        }
        private Object num() {
            int start = i;
            while (i < s.length() && "-+.eE0123456789".indexOf(s.charAt(i)) >= 0) i++;
            String t = s.substring(start, i);
            try { return Long.parseLong(t); } catch (Exception e) { return Double.parseDouble(t); }
        }
        static String str(Object o) {
            if (o == null) return "";
            if (o instanceof String st) return st;
            return String.valueOf(o);
        }
        static String esc(String s) {
            StringBuilder b = new StringBuilder();
            for (char c : s.toCharArray()) {
                switch (c) {
                    case '"': b.append("\\\""); break;
                    case '\\': b.append("\\\\"); break;
                    case '\n': b.append("\\n"); break;
                    case '\r': b.append("\\r"); break;
                    case '\t': b.append("\\t"); break;
                    default:
                        if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                        else b.append(c);
                }
            }
            return b.toString();
        }
    }

    // ------------------------------------------------------------------
    // Localisation du binaire hfllm
    // ------------------------------------------------------------------
    static Path hfllmPath() {
        for (String cand : new String[]{
                System.getenv("HFLLM_BIN"),
                "./bin/hfllm",
                "../bin/hfllm",
                "hfllm"}) {
            if (cand == null) continue;
            Path p = Path.of(cand);
            if (Files.exists(p)) return p.toAbsolutePath();
            if (cand.equals("hfllm")) return p; // sur le PATH
        }
        return Path.of("hfllm");
    }

    static String runHfllm(String... args) throws Exception {
        List<String> cmd = new ArrayList<>();
        cmd.add(hfllmPath().toString());
        Collections.addAll(cmd, args);
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(false);
        Process p = pb.start();
        String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        String err = new String(p.getErrorStream().readAllBytes(), StandardCharsets.UTF_8);
        boolean fin = p.waitFor(300, java.util.concurrent.TimeUnit.SECONDS);
        if (!fin) p.destroyForcibly();
        if (p.exitValue() != 0 && out.isBlank()) {
            throw new RuntimeException("hfllm " + String.join(" ", args) + " a échoué : " + err.trim());
        }
        return out;
    }

    // ------------------------------------------------------------------
    // HTTP
    // ------------------------------------------------------------------
    static void sendJson(com.sun.net.httpserver.HttpExchange x, int code, String json) throws IOException {
        byte[] b = json.getBytes(StandardCharsets.UTF_8);
        x.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        x.sendResponseHeaders(code, b.length);
        try (OutputStream os = x.getResponseBody()) { os.write(b); }
    }

    static void sendHtml(com.sun.net.httpserver.HttpExchange x, int code, String html) throws IOException {
        byte[] b = html.getBytes(StandardCharsets.UTF_8);
        x.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        x.sendResponseHeaders(code, b.length);
        try (OutputStream os = x.getResponseBody()) { os.write(b); }
    }

    static String readBody(com.sun.net.httpserver.HttpExchange x) throws IOException {
        return new String(x.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
    }

    @SuppressWarnings("unchecked")
    static void handleChat(com.sun.net.httpserver.HttpExchange x) throws IOException {
        try {
            Map<String, Object> req = (Map<String, Object>) Json.parse(readBody(x));
            String model = Json.str(req.get("model"));
            String session = Json.str(req.getOrDefault("session", "web"));
            String message = Json.str(req.get("message"));
            if (model.isBlank() || message.isBlank()) {
                sendJson(x, 400, "{\"error\":\"model et message requis\"}");
                return;
            }
            String out = runHfllm("run", model, message, "--session", session, "--json");
            // Sortie hfllm --json : peut contenir des lignes de log [.*] avant le JSON
            String jsonLine = extractJsonLine(out);
            Map<String, Object> parsed = (Map<String, Object>) Json.parse(jsonLine);
            Map<String, Object> resp = new LinkedHashMap<>();
            resp.put("reply", Json.str(parsed.get("reply")));
            resp.put("session", Json.str(parsed.getOrDefault("session", session)));
            resp.put("ms", parsed.getOrDefault("ms", 0));
            sendJson(x, 200, Json.esc("{}").isEmpty() ? "{}" : toJson(resp));
        } catch (Exception e) {
            sendJson(x, 500, "{\"error\":" + Json.esc(String.valueOf(e.getMessage())) + "}");
        }
    }

    @SuppressWarnings("unchecked")
    static String extractJsonLine(String out) {
        String t = out.trim();
        if (t.startsWith("[") && t.endsWith("]")) return t; // tableau JSON (multi-lignes)
        for (String line : out.split("\n")) {
            String l = line.trim();
            if (l.startsWith("{") && l.endsWith("}")) return l; // objet JSON sur une ligne
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("reply", out.trim());
        m.put("ms", 0);
        return toJson(m);
    }

    static String toJson(Map<String, Object> m) {
        StringBuilder b = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Object> e : m.entrySet()) {
            if (!first) b.append(",");
            first = false;
            b.append("\"").append(Json.esc(e.getKey())).append("\":");
            Object v = e.getValue();
            if (v instanceof Number || v instanceof Boolean) b.append(v);
            else if (v == null) b.append("null");
            else b.append("\"").append(Json.esc(String.valueOf(v))).append("\"");
        }
        return b.append("}").toString();
    }

    static void handleStatus(com.sun.net.httpserver.HttpExchange x) throws IOException {
        boolean llamaUp = false;
        try {
            HttpClient hc = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(1)).build();
            HttpRequest rq = HttpRequest.newBuilder(URI.create("http://127.0.0.1:11434/health"))
                    .timeout(Duration.ofSeconds(2)).GET().build();
            HttpResponse<String> r = hc.send(rq, HttpResponse.BodyHandlers.ofString());
            llamaUp = r.statusCode() == 200;
        } catch (Exception ignored) { }
        String stats;
        try { stats = extractJsonLine(runHfllm("mem", "stats", "--json")); }
        catch (Exception e) { stats = "{}"; }
        sendJson(x, 200, "{\"llamaServer\":" + llamaUp + ",\"hfllmPort\":11434,\"memory\":" + stats
                + ",\"dashboard\":\"v1.0\"}");
    }

    // ------------------------------------------------------------------
    // Page web
    // ------------------------------------------------------------------
    static final String PAGE = """
<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cousin LLM Launcher — Dashboard</title>
<style>
:root{--bg:#0d1117;--card:#161b22;--line:#30363d;--fg:#e6edf3;--dim:#8b949e;--acc:#e9573f;--ok:#3fb950;--warn:#d29922}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--fg);font:15px/1.55 system-ui,Segoe UI,Roboto,sans-serif;min-height:100vh;display:flex;flex-direction:column}
header{border-bottom:2px solid var(--acc);padding:18px 24px;background:linear-gradient(180deg,#161b22,#0d1117)}
h1{font-size:20px;letter-spacing:.4px}h1 .sac{color:var(--acc)}
.sub{color:var(--dim);font-size:13px;margin-top:3px}
main{flex:1;display:grid;grid-template-columns:340px 1fr;gap:16px;padding:16px 24px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}
.card h2{font-size:13px;text-transform:uppercase;letter-spacing:1px;color:var(--dim);margin-bottom:10px}
.pill{display:inline-block;padding:2px 10px;border-radius:99px;font-size:12px;border:1px solid var(--line)}
.pill.ok{color:var(--ok);border-color:var(--ok)} .pill.off{color:var(--warn);border-color:var(--warn)}
.model{padding:8px 10px;border:1px solid var(--line);border-radius:8px;margin-bottom:8px;cursor:pointer;font-size:14px}
.model:hover{border-color:var(--acc)} .model.sel{border-color:var(--acc);background:#1d2330}
.model .q{color:var(--dim);font-size:12px}
.stat{display:flex;justify-content:space-between;font-size:13px;padding:3px 0}
.stat span:last-child{color:var(--fg);font-weight:600}
.chatbox{display:flex;flex-direction:column;height:64vh}
.log{flex:1;overflow-y:auto;padding:8px 4px;border:1px solid var(--line);border-radius:8px;background:#0a0e14}
.msg{margin:8px 4px;max-width:78%}
.msg .who{font-size:11px;color:var(--dim);letter-spacing:.5px}
.msg .bub{padding:8px 12px;border-radius:10px;margin-top:2px;white-space:pre-wrap}
.msg.user .bub{background:#23304a;margin-left:auto} .msg.assistant .bub{background:#1d2330;border:1px solid var(--line)}
.row{display:flex;gap:8px;margin-top:10px}
input,select{background:#0a0e14;border:1px solid var(--line);color:var(--fg);border-radius:8px;padding:9px 12px;font-size:14px}
input[type=text]{flex:1}
button{background:var(--acc);border:none;color:#fff;padding:9px 18px;border-radius:8px;font-weight:600;cursor:pointer}
button:disabled{opacity:.5}
footer{color:var(--dim);text-align:center;padding:10px;font-size:12px}
footer .sac{color:var(--acc)}
@media(max-width:800px){main{grid-template-columns:1fr}.chatbox{height:56vh}}
</style></head><body>
<header>
  <h1>🕊️ Cousin <span class="sac">LLM Launcher</span> — Dashboard</h1>
  <div class="sub">En hommage au créateur originel — Repose en paix · Rust + C++ + Java, sans Ollama</div>
</header>
<main>
  <div style="display:flex;flex-direction:column;gap:16px">
    <div class="card">
      <h2>Serveur d'inférence</h2>
      <div><span id="pill" class="pill off">interroge…</span> <span style="color:var(--dim);font-size:12px">:11434</span></div>
    </div>
    <div class="card">
      <h2>Modèles</h2>
      <div id="models">chargement…</div>
    </div>
    <div class="card">
      <h2>Mémoire persistante</h2>
      <div id="mem">chargement…</div>
    </div>
  </div>
  <div class="card chatbox">
    <h2>Chat — session « <span id="sessName">web</span> » (persistée en SQLite)</h2>
    <div class="log" id="log"></div>
    <div class="row">
      <select id="sess" style="width:130px"><option value="web">web</option><option value="default">default</option></select>
      <input type="text" id="msg" placeholder="Votre message… (la mémoire survivra au redémarrage)" autofocus>
      <button id="send">Envoyer</button>
    </div>
  </div>
</main>
<footer>Cousin LLM Launcher v1.0 — <span class="sac">En hommage au créateur originel</span> · dashboard Java · moteur Rust hfllm · inspection C++ gguf-info</footer>
<script>
let model = null;
const $ = id => document.getElementById(id);
const esc = s => s.replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));

async function refresh(){
  try{
    const st = await (await fetch('/api/status')).json();
    const pill = $('pill');
    if(st.llamaServer){ pill.textContent='llama-server EN LIGNE'; pill.className='pill ok'; }
    else { pill.textContent='llama-server ARRÊTÉ'; pill.className='pill off'; }
    if(st.memory){
      $('mem').innerHTML =
        stat('Messages', st.memory.messages) + stat('Sessions', st.memory.sessions) +
        stat('Modèles', st.memory.models) + stat('Go GGUF', (st.memory.bytes/1e9).toFixed(2));
    }
    const ms = await (await fetch('/api/models')).json();
    const box = $('models');
    if(!Array.isArray(ms) || ms.length===0){ box.innerHTML='<div style="color:var(--dim)">Aucun modèle → <code>hfllm pull owner/repo</code></div>'; return; }
    box.innerHTML='';
    ms.forEach(m=>{
      const d=document.createElement('div');
      d.className='model'+(model===m.name?' sel':'');
      d.innerHTML='<div>'+esc(m.name)+'</div><div class="q">'+esc(m.repo)+' · '+(m.size/1e6).toFixed(0)+' Mo</div>';
      d.onclick=()=>{model=m.name;refresh();};
      box.appendChild(d);
    });
  }catch(e){ $('pill').textContent='hfllm introuvable'; }
}
const stat=(k,v)=>'<div class="stat"><span>'+k+'</span><span>'+v+'</span></div>';

async function send(){
  const msg=$('msg').value.trim(); if(!msg)return;
  if(!model){alert('Choisissez un modèle (ou : hfllm pull …)');return;}
  const sess=$('sess').value; $('sessName').textContent=sess;
  $('msg').value=''; add('user',msg);
  const b=$('send'); b.disabled=true;
  try{
    const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({model,session:sess,message:msg})});
    const j=await r.json();
    add('assistant', j.reply || ('[erreur] '+(j.error||'?')));
  }catch(e){ add('assistant','[erreur réseau] '+e); }
  b.disabled=false; $('msg').focus(); refresh();
}
function add(role,text){
  const d=document.createElement('div'); d.className='msg '+role;
  d.innerHTML='<div class="who">'+(role==='user'?'VOUS':'HFLLM')+'</div><div class="bub">'+esc(text)+'</div>';
  const log=$('log'); log.appendChild(d); log.scrollTop=log.scrollHeight;
}
$('send').onclick=send;
$('msg').addEventListener('keydown',e=>{if(e.key==='Enter')send();});
refresh(); setInterval(refresh, 5000);
</script>
</body></html>
""";

    // ------------------------------------------------------------------
    // main
    // ------------------------------------------------------------------
    public static void main(String[] args) throws Exception {
        int port = 8686;
        for (int i = 0; i < args.length - 1; i++) {
            if ("--port".equals(args[i])) port = Integer.parseInt(args[i + 1]);
        }
        HttpServer srv = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
        srv.setExecutor(Executors.newFixedThreadPool(8));

        srv.createContext("/", x -> {
            if ("GET".equals(x.getRequestMethod())) sendHtml(x, 200, PAGE);
            else sendJson(x, 405, "{\"error\":\"GET only\"}");
        });
        srv.createContext("/api/models", x -> {
            try { sendJson(x, 200, extractJsonLine(runHfllm("list", "--json"))); }
            catch (Exception e) { sendJson(x, 200, "[]"); }
        });
        srv.createContext("/api/sessions", x -> {
            try { sendJson(x, 200, extractJsonLine(runHfllm("mem", "list", "--json"))); }
            catch (Exception e) { sendJson(x, 200, "[]"); }
        });
        srv.createContext("/api/status", x -> {
            if ("GET".equals(x.getRequestMethod())) handleStatus(x);
            else sendJson(x, 405, "{\"error\":\"GET only\"}");
        });
        srv.createContext("/api/chat", x -> {
            if ("POST".equals(x.getRequestMethod())) handleChat(x);
            else sendJson(x, 405, "{\"error\":\"POST only\"}");
        });

        srv.start();
        System.out.println("──────────────────────────────────────────────────────");
        System.out.println(" Dashboard Cousin LLM Launcher : http://localhost:" + port);
        System.out.println(" hfllm : " + hfllmPath());
        System.out.println(" En hommage au créateur originel — Repose en paix.");
        System.out.println("──────────────────────────────────────────────────────");
    }
}
