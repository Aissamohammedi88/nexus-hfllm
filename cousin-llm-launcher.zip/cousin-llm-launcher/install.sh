#!/usr/bin/env bash
# ============================================================================
#  install.sh — Installe le Cousin LLM Launcher (remplace Ollama)
#  * copie hfllm (Rust), gguf-info (C++) et le backend llama.cpp
#  * installe dans ~/.hfllm + lien ~/.local/bin/hfllm
#  * optionnel : dashboard Java (java Dashboard.java)
# ============================================================================
set -Eeuo pipefail

B='\033[1;34m'; G='\033[1;32m'; Y='\033[1;33m'; R='\033[1;31m'; N='\033[0m'
say() { printf "${B}[*]${N} %s\n" "$1"; }
ok()  { printf "${G}[OK]${N} %s\n" "$1"; }
warn(){ printf "${Y}[!]${N}  %s\n" "$1"; }
err() { printf "${R}[X]${N} %s\n" "$1" >&2; }

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HFLLM_HOME="${HFLLM_HOME:-$HOME/.hfllm}"
ARCH="$(uname -m)"

say "Installation du Cousin LLM Launcher depuis $SRC"

# --- Vérifs de base
[[ "$(uname -s)" == "Linux" ]] || { err "Linux requis (binaires x86_64 glibc)"; exit 1; }
[[ "$ARCH" == "x86_64" ]] || warn "Architecture $ARCH : les binaires fournis sont x86_64. Recompilez via scripts/setup-backend.sh + rust-src."
command -v curl >/dev/null || { err "curl requis"; exit 1; }

# --- 1) hfllm (Rust) + gguf-info (C++)
say "Copie des binaires..."
mkdir -p "$HFLLM_HOME/bin" "$HFLLM_HOME/tools" "$HFLLM_HOME/backend/bin" "$HFLLM_HOME/models" "$HFLLM_HOME/logs"
cp -f "$SRC/bin/hfllm"     "$HFLLM_HOME/bin/"   && chmod +x "$HFLLM_HOME/bin/hfllm"
cp -f "$SRC/bin/gguf-info" "$HFLLM_HOME/tools/" && chmod +x "$HFLLM_HOME/tools/gguf-info"

# --- 2) Backend llama.cpp (si présent dans le zip)
if [[ -d "$SRC/bin/backend" ]]; then
  say "Copie du backend llama.cpp..."
  cp -f "$SRC/bin/backend/"*.so* "$HFLLM_HOME/backend/bin/" 2>/dev/null || true
  cp -f "$SRC/bin/backend/llama-server" "$HFLLM_HOME/backend/bin/" && chmod +x "$HFLLM_HOME/backend/bin/llama-server"
  ok "backend llama.cpp installé"
else
  warn "backend absent du zip → sera compilé par scripts/setup-backend.sh"
fi

# --- 3) Dashboard Java (copie du source)
mkdir -p "$HFLLM_HOME/java"
cp -f "$SRC/java/Dashboard.java" "$HFLLM_HOME/java/" 2>/dev/null || true

# --- 4) Lien dans PATH
mkdir -p "$HOME/.local/bin"
ln -sf "$HFLLM_HOME/bin/hfllm" "$HOME/.local/bin/hfllm"
case ":$PATH:" in
  *":$HOME/.local/bin:"*) ;;
  *) warn "$HOME/.local/bin n'est pas dans le PATH → ajoutez : export PATH=\"\$HOME/.local/bin:\$PATH\"" ;;
esac

# --- 5) Test
say "Test du binaire..."
if "$HFLLM_HOME/bin/hfllm" --version >/dev/null 2>&1; then
  ok "$("$HFLLM_HOME/bin/hfllm" --version)"
else
  err "hfllm ne démarre pas (glibc trop ancienne ?) → recompilez : cd rust-src && cargo build --release"
  exit 1
fi

echo
echo -e "${G}============================================================${N}"
echo -e "${G}  COUSIN LLM LAUNCHER INSTALLÉ${N}"
echo -e "${G}============================================================${N}"
echo "  Accueil      : $HFLLM_HOME"
echo "  Modèle 1er   : hfllm pull bartowski/Qwen2.5-0.5B-Instruct-GGUF"
echo "  Chat         : hfllm chat <modele>"
echo "  Serveur      : hfllm serve <modele>   (API OpenAI : :11434)"
echo "  Dashboard    : java java/Dashboard.java   (web : :8686)"
echo "  Mémoire      : hfllm mem list | show | stats"
echo
echo "  En hommage au créateur originel — Repose en paix."
