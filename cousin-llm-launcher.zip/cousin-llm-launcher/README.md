# 🕊️ Cousin LLM Launcher

**Remplace Ollama** : lance n'importe quel modèle GGUF de Hugging Face, avec **mémoire persistante** (SQLite) et **API OpenAI-compatible**.

*Rust + C++ + Java — en hommage au créateur originel. Repose en paix.*

---

## ⚡ Démarrage en 1 commande

```bash
unzip cousin-llm-launcher.zip
cd cousin-llm-launcher
bash install.sh      # une fois : installe dans ~/.hfllm + ~/.local/bin
bash launch.sh       # TOUT : modèle + serveur + dashboard web
```

→ **API**  : `http://localhost:11434/v1/chat/completions` (compatible OpenAI)
→ **Web**  : `http://localhost:8686` (chat + modèles + mémoire, dashboard Java)

---

## 🧱 Architecture — 3 langages, 3 métiers

| Module | Langage | Rôle |
|---|---|---|
| `hfllm` | **Rust** (4.4 Mo) | CLI + orchestrateur : `pull` HF, `serve`, `chat`, **mémoire SQLite persistante** |
| `gguf-info` | **C++17** | Inspecteur GGUF : magic, version, tensors, arch, quant, contexte (parsé octet par octet) |
| `Dashboard.java` | **Java 21** (zéro dépendance) | Dashboard web natif (`com.sun.net.httpserver`) + chat → `hfllm run --json` |
| `llama-server` | llama.cpp (C/C++) | Moteur d'inférence GGUF, API `/v1/chat/completions` |

```
vous ──▶ hfllm chat/run ──▶ llama-server (:11434) ──▶ modèle GGUF
              │
              ▼
        ~/.hfllm/memory.db   ◀── mémoire persistante (sessions, messages)
              │
Dashboard Java (:8686) ──▶ hfllm run --json  (même mémoire)
```

---

## 📖 Commandes hfllm (comme ollama, en mieux)

```bash
hfllm pull bartowski/Qwen2.5-0.5B-Instruct-GGUF     # télécharge le meilleur GGUF du dépôt
hfllm pull owner/repo:fichier-Q4_K_M.gguf           # fichier précis
hfllm list                                          # modèles installés
hfllm info <modele>                                 # métadonnées GGUF (via outil C++)
hfllm serve <modele>                                # API OpenAI sur :11434
hfllm serve <modele> --port 11435 --ctx 8192        # options
hfllm serve x --stop                                # arrête les serveurs
hfllm chat <modele>                                 # chat TTY, mémoire auto
hfllm chat <modele> --session projetA               # fils de discussion séparés
hfllm run <modele> "Ta question"                    # prompt unique (persisté aussi)
hfllm mem list | show | stats                       # la mémoire, en clair
hfllm mem clear --session projetA                   # efface un fil
hfllm rm <modele>                                   # désinstalle un modèle
```

## 🧠 Mémoire persistante — démonstration réelle

```
$ hfllm run Qwen2.5-0.5B-Instruct-Q4_K_M "Mon prénom est Nexus. Tu dois le retenir."
$ hfllm run Qwen2.5-0.5B-Instruct-Q4_K_M "Quel est mon prénom ?"
Nexus                        ← processus SÉPARÉ : lu depuis SQLite

$ hfllm serve x --stop       ← serveur arrêté
$ hfllm serve Qwen2.5-...    ← redémarré (nouveau pid)
$ hfllm run Qwen2.5-... "Rappelle-moi mon prénom."
Nexus                        ← survit au redémarrage
```

Historique complet : `hfllm mem show`. Tout est dans `~/.hfllm/memory.db` (tables `models`,
`sessions`, `messages`, `servers`). Le chat n'envoie que les **50 derniers messages** au modèle
(vitesse), mais **tout** est conservé en base (mémoire).

---

## 🌐 Dashboard web (Java)

- Modèles installés (cliquables), état du serveur, stats mémoire
- Chat par session (`web`, `default`, …) — la mémoire est la même que le CLI
- Aucune dépendance Maven/Gradle : `java Dashboard.java` (JDK 11+, compilé à la volée)

## 🔧 API HTTP (OpenAI-compatible)

```bash
curl http://localhost:11434/v1/chat/completions -d '{
  "messages": [{"role":"user","content":"Bonjour"}]
}' -H "Content-Type: application/json"
```
Tout client OpenAI fonctionne (pointeur `base_url=http://localhost:11434/v1`).

---

## 📦 Contenu du ZIP

```
cousin-llm-launcher/
├── launch.sh              ← TOUT EN 1 COMMANDE
├── install.sh             ← installation (~/.hfllm, PATH)
├── README.md              ← ce fichier
├── bin/
│   ├── hfllm              ← launcher Rust (x86_64 Linux)
│   ├── gguf-info          ← inspecteur C++
│   └── backend/           ← llama-server + libllama/ggml .so
├── java/Dashboard.java    ← dashboard web
├── rust-src/              ← Cargo.toml + src/main.rs (recompilable)
├── cpp-src/gguf_info.cpp  ← source C++ (recompilable)
├── scripts/setup-backend.sh ← recompile llama.cpp pour votre CPU
└── .gitignore
```

Les **modèles ne sont pas dans le ZIP** (des centaines de Mo) : `hfllm pull` les télécharge
depuis Hugging Face avec reprise et affichage de progression.

---

## 🛠️ Recompilation (autres machines)

```bash
# Rust
cd rust-src && cargo build --release --offline   # ou en ligne
# C++
g++ -O2 -std=c++17 -o gguf-info cpp-src/gguf_info.cpp
# Backend llama.cpp (requiert git cmake make g++)
bash scripts/setup-backend.sh
```

## ✅ Prérequis

- Linux x86_64 (glibc 2.31+) — binaires fournis
- `curl` (pull HF)
- Java 11+ **JDK** (seulement pour le dashboard web)
- GPU optionnel : recompilez llama.cpp avec `-DGGML_CUDA=ON` puis `hfllm serve <m> --ngl 99`

---

*Cousin LLM Launcher v1.0 — **En hommage au créateur originel. Ton héritage tourne encore.*** 🕊️
