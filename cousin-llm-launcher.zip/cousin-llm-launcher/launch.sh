#!/usr/bin/env bash
# ============================================================================
#  launch.sh — TOUT EN 1 COMMANDE (comme d'habitude)
#  * installe si besoin (install.sh)
#  * télécharge un modèle par défaut si aucun (Qwen2.5-0.5B-Instruct, 470 Mo)
#  * démarre llama-server (:11434, API OpenAI-compatible)
#  * démarre le dashboard web Java (:8686)
#  Usage :   bash launch.sh            → tout démarre
#            MODEL=hfllm-pull-repo bash launch.sh   (modèle différent)
#            bash launch.sh stop       → tout arrête
# ============================================================================
set -Eeuo pipefail

B='\033[1;34m'; G='\033[1;32m'; Y='\033[1;33m'; R='\033[1;31m'; N='\033[0m'
say() { printf "${B}[*]${N} %s\n" "$1"; }
ok()  { printf "${G}[OK]${N} %s\n" "$1"; }
warn(){ printf "${Y}[!]${N}  %s\n" "$1"; }
err() { printf "${R}[X]${N} %s\n" "$1" >&2; }

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HFLLM_HOME="${HFLLM_HOME:-$HOME/.hfllm}"
export HFLLM_HOME
HFLLM="$HFLLM_HOME/bin/hfllm"
DASH_PORT=8686
DEFAULT_MODEL_REPO="bartowski/Qwen2.5-0.5B-Instruct-GGUF"
DEFAULT_MODEL="Qwen2.5-0.5B-Instruct-Q4_K_M"

if [[ "${1:-}" == "stop" ]]; then
  say "Arrêt de tout..."
  "$HFLLM" serve x --stop >/dev/null 2>&1 || pkill -f llama-server || true
  pkill -f "Dashboard.java" 2>/dev/null || pkill -f "hfllm-dashboard" || true
  ok "Arrêté."
  exit 0
fi

# --- 1) Installation (idempotent)
if [[ ! -x "$HFLLM" ]]; then
  say "Premier lancement : installation..."
  bash "$SRC/install.sh"
fi

# --- 2) Backend présent ?
if ! "$HFLLM" serve x --stop >/dev/null 2>&1; then true; fi
if [[ ! -x "$HFLLM_HOME/backend/bin/llama-server" ]]; then
  say "Backend llama.cpp absent — compilation (5-15 min)..."
  bash "$SRC/scripts/setup-backend.sh"
fi

# --- 3) Modèle par défaut
MODEL="${MODEL:-}"
if [[ -z "$MODEL" ]]; then
  if ! "$HFLLM" list 2>/dev/null | grep -q "$DEFAULT_MODEL"; then
    say "Aucun modèle — téléchargement du modèle par défaut (470 Mo)..."
    "$HFLLM" pull "$DEFAULT_MODEL_REPO" || err "pull échoué — essayez : hfllm pull <owner/repo>"
  fi
  MODEL="$DEFAULT_MODEL"
fi

# --- 4) Serveur d'inférence
say "Démarrage du serveur d'inférence (modèle : $MODEL)..."
"$HFLLM" serve "$MODEL"

# --- 5) Dashboard Java
DASH_PID=""
if command -v java >/dev/null 2>&1; then
  say "Démarrage du dashboard web (port $DASH_PORT)..."
  if curl -fsS "http://localhost:$DASH_PORT/api/status" >/dev/null 2>&1; then
    ok "Dashboard déjà en ligne"
  else
    ( cd "$SRC/java" && HFLLM_BIN="$HFLLM" nohup java Dashboard.java --port "$DASH_PORT" \
        > "$HFLLM_HOME/logs/dashboard.log" 2>&1 & echo $! > "$HFLLM_HOME/dashboard.pid" )
    DASH_PID=$(cat "$HFLLM_HOME/dashboard.pid" 2>/dev/null || true)
    for i in $(seq 1 20); do
      curl -fsS "http://localhost:$DASH_PORT/api/status" >/dev/null 2>&1 && break
      sleep 1
    done
    ok "Dashboard lancé (pid $DASH_PID)"
  fi
else
  warn "java absent — dashboard indisponible (installez default-jdk pour l'UI web)"
fi

# --- 6) Récap
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
echo
echo -e "${G}============================================================${N}"
echo -e "${G}  🟢  COUSIN LLM LAUNCHER EST EN LIGNE${N}"
echo -e "${G}============================================================${N}"
echo -e "   API OpenAI   : ${B}http://localhost:11434/v1/chat/completions${N}"
echo -e "   Dashboard    : ${B}http://localhost:$DASH_PORT${N}"
[[ -n "$IP" ]] && echo -e "   Réseau       : ${B}http://$IP:$DASH_PORT${N}"
echo -e "   Chat TTY     : ${B}hfllm chat $MODEL${N}"
echo -e "   Mémoire      : ${B}hfllm mem show${N}  (persistante, SQLite)"
echo -e "   Log serveur  : $HFLLM_HOME/logs/llama-server-11434.log"
echo -e "   Arrêt        : ${Y}bash $SRC/launch.sh stop${N}"
echo
echo -e "   En hommage au créateur originel — Repose en paix."
echo
say "Pour quitter l'affichage : Ctrl+C (les serveurs restent actifs)"
sleep infinity 2>/dev/null || tail -f /dev/null
